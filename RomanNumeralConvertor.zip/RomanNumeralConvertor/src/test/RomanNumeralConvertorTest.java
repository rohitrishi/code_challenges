package test;

import production.RomanNumeralConvertor;
import static org.junit.Assert.*;
import org.junit.*;

public class RomanNumeralConvertorTest {
	
	RomanNumeralConvertor rnc;
	
	@Before
	public void beforeEach(){
		rnc = new RomanNumeralConvertor();
	}
	
	@Test
	public void outOfRangeValues(){
		try{
			rnc.convert(-1);
			fail("We should throw an exception for values less than 1, including negative values.");
		}
		catch(IllegalArgumentException e){
			
		}
		try{
			rnc.convert(3001);
			fail("We should throw an exception for values greater than 3000.");
		}
		catch(IllegalArgumentException e){
			
		}
	}
	
	@Test
	public void inRangeValues(){
		assertEquals("I", rnc.convert(1));
		assertEquals("II", rnc.convert(2));
		assertEquals("III", rnc.convert(3));
		assertEquals("IV", rnc.convert(4));
		assertEquals("V", rnc.convert(5));
		assertEquals("VI", rnc.convert(6));
		assertEquals("VII", rnc.convert(7));
		assertEquals("VIII", rnc.convert(8));
		assertEquals("IX", rnc.convert(9));
		assertEquals("X", rnc.convert(10));
		assertEquals("L", rnc.convert(50));
		assertEquals("C", rnc.convert(100));
		assertEquals("D", rnc.convert(500));
		assertEquals("M", rnc.convert(1000));
		assertEquals("DCCLXXXVI", rnc.convert(786));
		assertEquals("MMCMXCIX", rnc.convert(2999));
	}
}
