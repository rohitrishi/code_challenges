package production;

import java.util.Scanner;

public class RomanNumeralConvertor {
	private static final int TEN_DIVISOR = 10;
	private static final int HUNDRED_DIVISOR = 100;
	private static final int THOUSAND_DIVISOR = 1000;
	private static final int MID_VALUE = 5;
	private static final int MAX = 3000;
	private static final int MIN = 1;
	
	public String convert(int value){
		StringBuilder romanValue = new StringBuilder("");
		if(value < MIN || value > MAX){
			throw new IllegalArgumentException("Out of range value. Acceptable range is 1 to 3000(inclusive).");
		}
		int unitsPlace = value%TEN_DIVISOR;
		int tensPlace = (value-unitsPlace)%HUNDRED_DIVISOR;
		int hundredPlace = (value-(tensPlace+unitsPlace))%THOUSAND_DIVISOR;
		int thousandsPlace = value/THOUSAND_DIVISOR;
		
		romanValue.append(this.generateRepetition(thousandsPlace, "M"));
		romanValue.append(this.convertSubNumber(hundredPlace/HUNDRED_DIVISOR, "C", "D", "M"));
		romanValue.append(this.convertSubNumber(tensPlace/TEN_DIVISOR, "X", "L", "C"));
		romanValue.append(this.convertSubNumber(unitsPlace, "I", "V", "X"));
		
		return romanValue.toString();	
	}
	
	private String convertSubNumber(int value, String low, String mid, String high){
		switch(value){
			case 0:
				return "";
			case 1:
			case 2:
			case 3:
				return this.generateRepetition(value, low);
			case 4:
				return low+mid;
			case 5:
			case 6:
			case 7:
			case 8:
				return mid+this.generateRepetition(value-MID_VALUE, low);
			case 9:
				return low+high;
			default:
				throw new IllegalArgumentException("Conversion Failed, please try again.");
		}
	}
	
	private String generateRepetition(int value, String low){
		StringBuilder lowNumber = new StringBuilder();
		for (int i =0; i<value; i++){
			lowNumber.append(low); 
		}
		return lowNumber.toString();
	}
	
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		RomanNumeralConvertor rnc = new RomanNumeralConvertor();
		while(true){
			System.out.print("Please enter the decimal number to convert or exit to terminate: ");
			String input = scan.next();
			if(input.equalsIgnoreCase("exit")){
				break;
			}
			else{
				try{
					int value = Integer.parseInt(input);
					System.out.println("The roman value is: "+rnc.convert(value));
				}
				catch (NumberFormatException e){
					System.out.println("Invalid input. Please enter valid integer value.");
				}
				catch(IllegalArgumentException e){
					System.out.println(e.getMessage());
				}
				catch(Exception e){
					System.out.println("Non-recoverable error. Exiting program.");
					break;
				}
			}	
		}
		scan.close();
	}
}
