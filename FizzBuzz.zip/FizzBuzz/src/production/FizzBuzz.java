package production;

import java.util.Scanner;

public class FizzBuzz {
	
	private static final int FIZZ_DIVIDER = 3;
	private static final int BUZZ_DIVIDER = 5;
	private static final String FIZZ_DIVIDER_STRING = "3";
	private static final String BUZZ_DIVIDER_STRING = "5";
	
	private int m_limit = 1;
	
	public static final String FIZZ_CODE = "Fizz";
	public static final String BUZZ_CODE = "Buzz";
	
	public FizzBuzz(int limit){
		if(limit > 1){
			this.m_limit = limit;
		}
	}
	
	public int getLimit(){
		return this.m_limit;
	}
	
	public String[] getStageOneList(){
		String[] list = new String[this.m_limit];
		for(int i = 0; i<list.length; i++){
			list[i]=this.convertNumberForStageOne(i+1);
		}
		return list;
	}
	
	public String convertNumberForStageOne(int i){
		if(i<1 || i > this.m_limit){
			throw new IllegalArgumentException("Out of range input value.");
		}
		else{
			String value;
			if((i)%FIZZ_DIVIDER == 0 &&(i)%BUZZ_DIVIDER == 0){
				value=FIZZ_CODE+BUZZ_CODE;
			}
			else if((i)%FIZZ_DIVIDER == 0){
				value=FIZZ_CODE;
			}
			else if((i)%BUZZ_DIVIDER == 0){
				value=BUZZ_CODE;
			}
			else{
				value=Integer.toString(i);
			}
			return value;
		}
	}
	
	public String[] getStageTwoList(){
		String[] list = new String[this.m_limit];
		for(int i = 0; i<list.length; i++){
			list[i]=this.convertNumberForStageTwo(i+1);
		}
		return list;
	}
	
	public String convertNumberForStageTwo(int i){
		if(i<1 || i > this.m_limit){
			throw new IllegalArgumentException("Out of range input value.");
		}
		else{
			String convertedValue;
			String value = Integer.toString(i);
			if((value.indexOf(FIZZ_DIVIDER_STRING) != -1 || (i)%FIZZ_DIVIDER == 0) && 
					(value.indexOf(BUZZ_DIVIDER_STRING) != -1 || (i)%BUZZ_DIVIDER == 0)){
				convertedValue = FIZZ_CODE+BUZZ_CODE;
			}
			else if(value.indexOf(FIZZ_DIVIDER_STRING) != -1 || (i)%FIZZ_DIVIDER == 0){
				convertedValue = FIZZ_CODE;
			}
			else if(value.indexOf(BUZZ_DIVIDER_STRING) != -1 || (i)%BUZZ_DIVIDER == 0){
				convertedValue = BUZZ_CODE;
			}
			else{
				convertedValue=value;
			}
			return convertedValue;
		}
	}
	
	public static void main (String[] args){
		Scanner scan = new Scanner(System.in);
		FizzBuzz fb = new FizzBuzz(100);
		while(true){
			System.out.print("Please enter what stage(1 or 2) you want to print the list for and exit to terminate: ");
			String input = scan.next();
			if(input.equalsIgnoreCase("exit")){
				break;
			}
			else{
				String[] generatedArray = null;
				if(input.equalsIgnoreCase("1")){
					generatedArray = fb.getStageOneList();
				}
				else if(input.equalsIgnoreCase("2")){
					generatedArray = fb.getStageTwoList();
				}
				else{
					System.out.println("Invalid input. Please enter a valid input value (1, 2 or exit).");
				}
				if(generatedArray !=null){
					for(int i=0; i<generatedArray.length; i++){
						System.out.println(generatedArray[i]);
					}
				}
			}	
		}
		scan.close();
	}
}
