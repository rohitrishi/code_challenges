package test;

import production.FizzBuzz;
import static org.junit.Assert.*;
import org.junit.*;

public class FizzBuzzTest {
	
	@Test
	public void testConstructor(){
		FizzBuzz fb = new FizzBuzz(-1);
		assertEquals(1, fb.getLimit());
		fb = new FizzBuzz(25);
		assertEquals(25, fb.getLimit());
	}
	
	@Test
	public void testConvertForStageOneInvalidInput(){
		FizzBuzz fb = new FizzBuzz(10);
		try{
			fb.convertNumberForStageOne(-1);
			fail("We do not support negative number conversion, hence the test should have failed.");
		}
		catch(IllegalArgumentException e){
			
		}
		try{
			fb.convertNumberForStageOne(15);
			fail("We should not have computed that value as it is greater than the limit set in the constructor.");
		}
		catch(IllegalArgumentException e){
			
		}
	}
	
	@Test
	public void testConvertForStageTwoInvalidInput(){
		FizzBuzz fb = new FizzBuzz(10);
		try{
			fb.convertNumberForStageTwo(-1);
			fail("We do not support negative number conversion, hence the test should have failed.");
		}
		catch(IllegalArgumentException e){
			
		}
		try{
			fb.convertNumberForStageOne(15);
			fail("We should not have computed that value as it is greater than the limit set in the constructor.");
		}
		catch(IllegalArgumentException e){
			
		}
	}
	
	@Test
	public void testConvertForStageOneValidInput(){
		FizzBuzz fb = new FizzBuzz(100);
		assertEquals("2", fb.convertNumberForStageOne(2));
		assertEquals(FizzBuzz.FIZZ_CODE, fb.convertNumberForStageOne(3));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageOne(5));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageOne(25));
		assertEquals("31", fb.convertNumberForStageOne(31));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageOne(35));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageOne(45));
		assertEquals(FizzBuzz.FIZZ_CODE, fb.convertNumberForStageOne(51));
		assertEquals("53", fb.convertNumberForStageOne(53));
		assertEquals(FizzBuzz.FIZZ_CODE, fb.convertNumberForStageOne(54));
		assertEquals("56", fb.convertNumberForStageOne(56));
	}
	
	@Test
	public void testConvertForStageTwoValidInput(){
		FizzBuzz fb = new FizzBuzz(100);
		assertEquals("2", fb.convertNumberForStageOne(2));
		assertEquals(FizzBuzz.FIZZ_CODE, fb.convertNumberForStageTwo(3));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(5));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(25));
		assertEquals(FizzBuzz.FIZZ_CODE, fb.convertNumberForStageTwo(31));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(35));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(45));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(51));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(53));
		assertEquals(FizzBuzz.FIZZ_CODE+FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(54));
		assertEquals(FizzBuzz.BUZZ_CODE, fb.convertNumberForStageTwo(56));
	}
	
	//Now Ideally I would have done the following code using EasyMock but I don't want to introduce too many dependencies
	//So mocking the class the following way.
	public class MockFizzBuzz extends FizzBuzz{
		public int numInvokesS1 = 0;
		public int numInvokesS2 = 0;
		public MockFizzBuzz(int limit){
			super(limit);
		}
		
		public String convertNumberForStageOne(int i){
			numInvokesS1++;
			return Integer.toString(numInvokesS1);
		}
		
		public String convertNumberForStageTwo(int i){
			numInvokesS2++;
			return Integer.toString(numInvokesS2)+"a";
		}
	}
	
	@Test
	public void testGetStage1List(){
		MockFizzBuzz mfb = new MockFizzBuzz(2);
		String[] expected = {"1", "2"};
		assertArrayEquals(expected, mfb.getStageOneList());
	}
	
	@Test
	public void testGetStage2List(){
		MockFizzBuzz mfb = new MockFizzBuzz(2);
		String[] expected = {"1a", "2a"};
		assertArrayEquals(expected, mfb.getStageTwoList());
	}
}
